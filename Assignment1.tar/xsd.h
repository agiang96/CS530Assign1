/* Members: Alexander Giang, Shawn Chua
 * Class Users: cssc0885, cssc0894
 * Class Information: CS530, Spring 2017
 * Assignment #1, HexDump
 * Filename: xsd.h
 */

void binDump(char file[50]);
void hexDump(char file[50]);
